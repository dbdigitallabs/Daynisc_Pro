# Daynisc Pro Windows Setup Script
Write-Host "Setting up Daynisc Pro Desktop shortcut..." -ForegroundColor Cyan
$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop)
$Shortcut = $WshShell.CreateShortcut("$DesktopPath\Daynisc Pro.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\Daynisc-Pro.bat"
$Shortcut.Description = "Daynisc Pro Accounting Automation"
$Shortcut.Save()
Write-Host "Desktop shortcut created successfully! You can now launch Daynisc Pro from your desktop." -ForegroundColor Green
Start-Process "$PSScriptRoot\Daynisc-Pro.bat"
