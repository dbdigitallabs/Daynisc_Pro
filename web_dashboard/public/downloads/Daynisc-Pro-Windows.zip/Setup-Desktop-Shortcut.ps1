# Daynisc Pro Windows Setup Script
Write-Host "Creating Daynisc Pro Desktop shortcut..." -ForegroundColor Cyan
$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop)
$Shortcut = $WshShell.CreateShortcut("$DesktopPath\Daynisc Pro.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\Daynisc-Pro-Setup.exe"
$Shortcut.Description = "Daynisc Pro Accounting Automation"
$Shortcut.Save()
Write-Host "Desktop shortcut created! Starting Daynisc Pro..." -ForegroundColor Green
Start-Process "$PSScriptRoot\Daynisc-Pro-Setup.exe"
