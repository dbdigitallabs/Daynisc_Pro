@echo off
title Daynisc Pro - Windows Desktop Runner
echo ===================================================
echo           DAYNISC PRO - ACCOUNTING AUTOMATION
echo ===================================================
echo.
echo Starting Daynisc Pro in Desktop Application Mode...
echo Connecting to local TallyPrime (Port 9000) and Odoo ERP...
echo.

:: Try opening with Edge or Chrome in App Mode (Native Desktop Window)
where msedge >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start msedge --app=https://webdashboard-dun.vercel.app/#/ai-verification --window-size=1440,900
    goto :done
)

where chrome >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start chrome --app=https://webdashboard-dun.vercel.app/#/ai-verification --window-size=1440,900
    goto :done
)

:: Fallback standard browser
start https://webdashboard-dun.vercel.app/#/ai-verification

:done
echo Daynisc Pro Desktop window opened successfully!
exit
