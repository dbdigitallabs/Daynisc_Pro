@echo off
title Daynisc Pro - Windows Desktop Application
echo Starting Daynisc Pro Desktop Application...

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=https://webdashboard-dun.vercel.app/#/ai-verification --window-size=1440,900
    exit
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app=https://webdashboard-dun.vercel.app/#/ai-verification --window-size=1440,900
    exit
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=https://webdashboard-dun.vercel.app/#/ai-verification --window-size=1440,900
    exit
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=https://webdashboard-dun.vercel.app/#/ai-verification --window-size=1440,900
    exit
)

start https://webdashboard-dun.vercel.app/#/ai-verification
exit
