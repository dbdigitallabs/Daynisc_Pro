@echo off
title Daynisc Pro - Windows Desktop Application
start Daynisc-Pro-Setup.exe
