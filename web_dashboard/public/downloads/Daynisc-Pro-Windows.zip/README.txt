===================================================
   DAYNISC PRO - WINDOWS DESKTOP APPLICATION
===================================================

1. Double-click Daynisc-Pro-Setup.exe to start the desktop app.
2. (Optional) Run Setup-Desktop-Shortcut.ps1 to create a desktop icon.
3. Connect directly with TallyPrime (Port 9000) or Odoo ERP (Port 8069).
