===================================================
   DAYNISC PRO - WINDOWS DESKTOP APPLICATION
===================================================

HOW TO RUN:
1. Double-click 'Daynisc-Pro.bat' or 'Daynisc-Pro-Setup.exe' to launch Daynisc Pro in a dedicated native desktop window.
2. (Optional) Right-click 'Setup-Desktop-Shortcut.ps1' -> 'Run with PowerShell' to create a desktop shortcut icon.
3. Open TallyPrime (Port 9000) or Odoo ERP (Port 8069) on your PC to auto-connect.

Support: support@daynisc.com
