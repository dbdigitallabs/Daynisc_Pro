===================================================
   DAYNISC PRO - WINDOWS DESKTOP APPLICATION
===================================================

Thank you for downloading Daynisc Pro!

HOW TO RUN:
1. Double click 'Daynisc-Pro.bat' to launch Daynisc Pro in desktop mode.
2. Ensure TallyPrime is running with ODBC / Port 9000 enabled, or Odoo ERP is running on Port 8069.
3. Daynisc Pro will automatically detect your local ERP and begin processing invoices.

OFFLINE & LOCAL SYNC:
Daynisc Pro connects directly to your local computer's TallyPrime and Odoo ERP instances.
Your accounting data remains 100% private and on your device.

Need Help? Contact: support@daynisc.com
